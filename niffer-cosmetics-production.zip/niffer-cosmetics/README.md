# Niffer Cosmetics — Full Stack E-Commerce (Tanzania)

Bilingual EN/SW • Pesapal mobile money • Referrals • Admin • SMS

## Quick start (Windows / Mac / Linux)

### Backend
```bash
cd backend
npm install
npx prisma generate
npx prisma db push
npm run db:seed
npm run dev
```
→ http://localhost:4000

| Role | Phone | Password |
|------|-------|----------|
| Admin | 255700000001 | admin123 |
| Customer | 255712345678 | demo123 |

### Frontend
```bash
# from project root
npx serve .
```
→ http://localhost:3000

### Admin
Open `/admin.html` and login with admin credentials.

## Production

See **`backend/PRODUCTION.md`** for:
- PostgreSQL switch
- Pesapal sandbox → live
- Africa’s Talking SMS
- Security & deploy checklist

## Structure
```
niffer-cosmetics/
├── *.html, js/, css/     Frontend
├── admin.html            Admin UI
├── payment-callback.html Pesapal return page
└── backend/              Node + Express + Prisma API
```
