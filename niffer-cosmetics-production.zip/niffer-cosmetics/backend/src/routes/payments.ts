import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import { AppError } from '../middleware/errorHandler.js';
import * as pesapal from '../services/pesapal.js';
import { sendPaymentSuccess, sendOrderConfirmation } from '../services/sms.js';

const router = Router();
const prisma = new PrismaClient();

// POST /api/payments/initiate
router.post('/initiate', async (req, res, next) => {
  try {
    const { orderNumber } = z.object({ orderNumber: z.string() }).parse(req.body);

    const order = await prisma.order.findUnique({ where: { orderNumber } });
    if (!order) throw new AppError('Order not found', 404);
    if (order.paymentStatus === 'COMPLETED') throw new AppError('Order already paid', 400);

    if (!pesapal.isPesapalConfigured()) {
      return res.json({
        success: true,
        demo: true,
        message: 'Pesapal not configured — demo mode. Set PESAPAL_CONSUMER_KEY/SECRET in .env',
        data: {
          order_tracking_id: 'DEMO-' + order.orderNumber,
          redirect_url: `${process.env.APP_URL || 'http://localhost:3000'}/payment-callback.html?order=${order.orderNumber}&status=demo`,
          merchant_reference: order.orderNumber,
        },
      });
    }

    const notificationId = process.env.PESAPAL_IPN_ID || '';
    if (!notificationId) {
      throw new AppError(
        'PESAPAL_IPN_ID missing. Run: npm run pesapal:register-ipn (after setting PESAPAL_IPN_URL)',
        400
      );
    }

    const nameParts = order.customerName.trim().split(/\s+/);
    const result = await pesapal.submitOrder({
      id: order.orderNumber,
      currency: 'TZS',
      amount: order.total,
      description: `Niffer Cosmetics Order ${order.orderNumber}`.slice(0, 100),
      callback_url:
        process.env.PESAPAL_CALLBACK_URL ||
        `${process.env.APP_URL || 'http://localhost:3000'}/payment-callback.html`,
      notification_id: notificationId,
      billing_address: {
        email_address: order.customerEmail || undefined,
        phone_number: order.customerPhone.startsWith('+')
          ? order.customerPhone
          : order.customerPhone.startsWith('255')
            ? `+${order.customerPhone}`
            : `+255${order.customerPhone.replace(/^0/, '')}`,
        country_code: 'TZ',
        first_name: nameParts[0] || 'Customer',
        last_name: nameParts.slice(1).join(' ') || nameParts[0] || 'Customer',
        line_1: order.shippingAddress,
        city: order.shippingCity,
        state: order.shippingRegion || undefined,
      },
    });

    await prisma.order.update({
      where: { id: order.id },
      data: {
        pesapalTrackingId: result.order_tracking_id,
        pesapalMerchantRef: result.merchant_reference,
      },
    });

    res.json({
      success: true,
      data: {
        order_tracking_id: result.order_tracking_id,
        redirect_url: result.redirect_url,
        merchant_reference: result.merchant_reference,
      },
    });
  } catch (err) {
    next(err);
  }
});

async function markOrderPaid(orderId: string, orderNumber: string, phone: string) {
  const order = await prisma.order.update({
    where: { id: orderId },
    data: {
      paymentStatus: 'COMPLETED',
      status: 'PAID',
      paidAt: new Date(),
    },
  });

  // Approve pending commissions for this order
  await prisma.commission.updateMany({
    where: { orderId, status: 'PENDING' },
    data: { status: 'APPROVED' },
  });

  await sendPaymentSuccess(phone, orderNumber).catch(() => {});
  await sendOrderConfirmation(phone, orderNumber, order.total).catch(() => {});
  return order;
}

// POST /api/payments/ipn — Pesapal webhook (must be public HTTPS in production)
router.post('/ipn', async (req, res) => {
  try {
    const trackingId =
      req.body?.OrderTrackingId ||
      req.body?.orderTrackingId ||
      req.query?.OrderTrackingId ||
      req.query?.orderTrackingId;

    if (!trackingId) {
      return res.status(400).json({ error: 'Missing OrderTrackingId' });
    }

    const status = await pesapal.getTransactionStatus(String(trackingId));
    const desc = (status.payment_status_description || '').toUpperCase();

    const order = await prisma.order.findFirst({
      where: {
        OR: [
          { pesapalTrackingId: String(trackingId) },
          { orderNumber: status.merchant_reference || undefined },
        ],
      },
    });

    if (order && (desc === 'COMPLETED' || desc === 'PAID' || status.status_code === 1)) {
      if (order.paymentStatus !== 'COMPLETED') {
        await markOrderPaid(order.id, order.orderNumber, order.customerPhone);
      }
    } else if (order && (desc === 'FAILED' || desc === 'INVALID')) {
      await prisma.order.update({
        where: { id: order.id },
        data: { paymentStatus: 'FAILED' },
      });
    }

    // Pesapal expects 200
    res.json({
      orderNotificationType: 'IPNCHANGE',
      orderTrackingId: trackingId,
      status: 200,
    });
  } catch (err: any) {
    console.error('[IPN]', err?.message || err);
    res.status(200).json({ status: 200 }); // still 200 so Pesapal does not retry forever aggressively
  }
});

// GET IPN (some Pesapal setups use GET)
router.get('/ipn', async (req, res) => {
  req.body = { OrderTrackingId: req.query.OrderTrackingId || req.query.orderTrackingId };
  return (router as any).handle(
    { ...req, method: 'POST', url: '/ipn' } as any,
    res,
    () => {}
  );
});

// GET /api/payments/status/:orderNumber
router.get('/status/:orderNumber', async (req, res, next) => {
  try {
    const order = await prisma.order.findUnique({
      where: { orderNumber: req.params.orderNumber },
      select: {
        orderNumber: true,
        paymentStatus: true,
        status: true,
        total: true,
        paidAt: true,
        pesapalTrackingId: true,
      },
    });
    if (!order) throw new AppError('Order not found', 404);

    // Optionally refresh from Pesapal if still pending
    if (order.pesapalTrackingId && order.paymentStatus === 'PENDING' && pesapal.isPesapalConfigured()) {
      try {
        const st = await pesapal.getTransactionStatus(order.pesapalTrackingId);
        const desc = (st.payment_status_description || '').toUpperCase();
        if (desc === 'COMPLETED' || st.status_code === 1) {
          const full = await prisma.order.findUnique({ where: { orderNumber: order.orderNumber } });
          if (full) {
            await markOrderPaid(full.id, full.orderNumber, full.customerPhone);
            order.paymentStatus = 'COMPLETED';
            order.status = 'PAID';
          }
        }
      } catch {
        /* ignore */
      }
    }

    res.json({ success: true, data: order });
  } catch (err) {
    next(err);
  }
});

// Demo: mark paid without Pesapal (local testing only)
router.post('/demo-complete', async (req, res, next) => {
  try {
    if (process.env.NODE_ENV === 'production') {
      throw new AppError('Not available in production', 403);
    }
    const { orderNumber } = z.object({ orderNumber: z.string() }).parse(req.body);
    const order = await prisma.order.findUnique({ where: { orderNumber } });
    if (!order) throw new AppError('Order not found', 404);
    await markOrderPaid(order.id, order.orderNumber, order.customerPhone);
    res.json({ success: true, message: 'Order marked paid (demo)' });
  } catch (err) {
    next(err);
  }
});

export default router;
